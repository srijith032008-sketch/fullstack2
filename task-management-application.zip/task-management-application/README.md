# TaskFlow — Task Management Application

A complete full-stack task management project based on the assignment requirements.

## Features

- User registration and login
- JWT authentication and authorization
- Password hashing with bcrypt
- Create, read, update and delete tasks
- Task status: To Do / In Progress / Completed
- Task priority: Low / Medium / High
- Due dates
- Search and filters
- Responsive desktop/mobile UI
- Real-time task events using Socket.IO
- MongoDB persistence
- REST API
- Protected user-specific task data

## Technology stack

Frontend:
- HTML5
- CSS3
- Vanilla JavaScript

Backend:
- Node.js
- Express.js
- Socket.IO

Database:
- MongoDB + Mongoose

Authentication:
- JWT
- bcryptjs

## Setup

### 1. Install Node.js

Use Node.js 18 or newer.

### 2. Install packages

Open a terminal in this folder:

```bash
npm install
```

### 3. Create MongoDB database

Create a free MongoDB Atlas cluster and database.

Copy `.env.example` to `.env` and fill in:

```env
PORT=5000
MONGODB_URI=your_mongodb_atlas_connection_string
JWT_SECRET=your_long_random_secret
```

### 4. Start

```bash
npm start
```

For development:

```bash
npm run dev
```

Open:

```text
http://localhost:5000
```

## API

### Authentication

```http
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
```

### Tasks

All task routes require:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

Routes:

```http
GET    /api/tasks
POST   /api/tasks
PUT    /api/tasks/:id
DELETE /api/tasks/:id
```

## How the application works

1. User registers or logs in.
2. Server returns a JWT.
3. Browser stores the JWT in localStorage.
4. The JWT is attached to protected API requests.
5. Each task belongs to the authenticated user.
6. MongoDB stores users and tasks.
7. Socket.IO sends task create/update/delete events in real time.

## Assignment checklist

✓ User authentication & authorization
✓ CRUD operations for tasks
✓ Real-time updates using WebSockets
✓ Responsive design for web and mobile
✓ Full-stack API integration
✓ Dynamic data handling
✓ Database persistence

## Deployment

You can deploy the Node.js application to Render, Railway, or another Node-compatible host.

Set:
- Build command: `npm install`
- Start command: `npm start`

Add `MONGODB_URI` and `JWT_SECRET` as environment variables.

For a school submission, include screenshots of:
1. Registration/login
2. Dashboard
3. Creating a task
4. Editing/deleting a task
5. MongoDB task collection
6. API response
7. Mobile responsive view
