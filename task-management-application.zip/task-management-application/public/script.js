let token = localStorage.getItem("taskflow_token");
let currentUser = null;
let tasks = [];
let activeFilter = "all";
let socket = null;

const $ = id => document.getElementById(id);

function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2500);
}

function api(path, options = {}) {
  return fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  }).then(async r => {
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.message || "Something went wrong");
    return data;
  });
}

function switchAuthTab(tab) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  $("loginForm").classList.toggle("hidden", tab !== "login");
  $("registerForm").classList.toggle("hidden", tab !== "register");
}

document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => switchAuthTab(btn.dataset.tab)));

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email: $("loginEmail").value, password: $("loginPassword").value })
    });
    saveSession(data);
  } catch (err) { showToast(err.message); }
});

$("registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  try {
    const data = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({
        name: $("regName").value,
        email: $("regEmail").value,
        password: $("regPassword").value
      })
    });
    saveSession(data);
  } catch (err) { showToast(err.message); }
});

function saveSession(data) {
  token = data.token;
  currentUser = data.user;
  localStorage.setItem("taskflow_token", token);
  localStorage.setItem("taskflow_user", JSON.stringify(currentUser));
  openApp();
}

function logout() {
  token = null;
  currentUser = null;
  localStorage.removeItem("taskflow_token");
  localStorage.removeItem("taskflow_user");
  if (socket) socket.disconnect();
  $("appView").classList.add("hidden");
  $("authView").classList.remove("hidden");
}

$("logoutBtn").addEventListener("click", logout);

async function openApp() {
  $("authView").classList.add("hidden");
  $("appView").classList.remove("hidden");
  $("userName").textContent = currentUser.name;
  $("welcomeName").textContent = currentUser.name.split(" ")[0];
  await loadTasks();
  connectSocket();
}

async function loadTasks() {
  try {
    tasks = await api("/api/tasks");
    render();
  } catch (err) {
    showToast(err.message);
    if (err.message.toLowerCase().includes("token")) logout();
  }
}

function connectSocket() {
  if (!window.io || !token) return;
  socket = io();
  socket.on("connect", () => {
    $("connectionDot").style.background = "#10b981";
    $("connectionText").textContent = "Live updates on";
    socket.emit("authenticate", token);
  });
  socket.on("disconnect", () => {
    $("connectionDot").style.background = "#f59e0b";
    $("connectionText").textContent = "Offline";
  });
  socket.on("task:created", task => {
    if (!tasks.some(t => t._id === task._id)) tasks.unshift(task);
    render();
  });
  socket.on("task:updated", task => {
    const i = tasks.findIndex(t => t._id === task._id);
    if (i >= 0) tasks[i] = task;
    render();
  });
  socket.on("task:deleted", data => {
    tasks = tasks.filter(t => t._id !== data.id);
    render();
  });
}

function render() {
  const search = $("searchInput").value.toLowerCase().trim();
  const filtered = tasks.filter(task => {
    const matchesFilter = activeFilter === "all" || task.status === activeFilter;
    const matchesSearch = `${task.title} ${task.description}`.toLowerCase().includes(search);
    return matchesFilter && matchesSearch;
  });

  $("totalCount").textContent = tasks.length;
  $("todoCount").textContent = tasks.filter(t => t.status === "todo").length;
  $("progressCount").textContent = tasks.filter(t => t.status === "progress").length;
  $("doneCount").textContent = tasks.filter(t => t.status === "done").length;

  $("taskGrid").innerHTML = filtered.map(taskCard).join("");
  $("emptyState").classList.toggle("hidden", filtered.length !== 0);
}

function taskCard(t) {
  const status = { todo: "To Do", progress: "In Progress", done: "Completed" }[t.status];
  const due = t.dueDate ? new Date(t.dueDate).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "No due date";
  return `
    <article class="task-card">
      <div class="task-meta">
        <span class="badge status-${t.status}">${status}</span>
        <span class="badge priority-${t.priority}">${t.priority.toUpperCase()}</span>
      </div>
      <h3>${esc(t.title)}</h3>
      <p>${esc(t.description || "No description added.")}</p>
      <div class="task-footer">
        <span class="due">📅 ${due}</span>
        <div class="actions">
          <button class="icon-btn" onclick="editTask('${t._id}')">✎</button>
          <button class="icon-btn delete" onclick="deleteTask('${t._id}')">🗑</button>
        </div>
      </div>
    </article>`;
}

function esc(s = "") {
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

$("addTaskBtn").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("taskModal").addEventListener("click", e => { if (e.target === $("taskModal")) closeModal(); });

function openModal(task = null) {
  $("taskModal").classList.remove("hidden");
  $("taskId").value = task?._id || "";
  $("taskTitle").value = task?.title || "";
  $("taskDescription").value = task?.description || "";
  $("taskStatus").value = task?.status || "todo";
  $("taskPriority").value = task?.priority || "medium";
  $("taskDueDate").value = task?.dueDate ? task.dueDate.slice(0,10) : "";
  $("modalEyebrow").textContent = task ? "EDIT TASK" : "NEW TASK";
  $("modalTitle").textContent = task ? "Update task" : "Create a task";
  $("saveTaskBtn").textContent = task ? "Update Task" : "Create Task";
  $("taskTitle").focus();
}

function closeModal() { $("taskModal").classList.add("hidden"); }

window.editTask = id => {
  const task = tasks.find(t => t._id === id);
  if (task) openModal(task);
};

window.deleteTask = async id => {
  if (!confirm("Delete this task?")) return;
  try {
    await api(`/api/tasks/${id}`, { method: "DELETE" });
    tasks = tasks.filter(t => t._id !== id);
    render();
    showToast("Task deleted");
  } catch (err) { showToast(err.message); }
};

$("taskForm").addEventListener("submit", async e => {
  e.preventDefault();
  const id = $("taskId").value;
  const body = {
    title: $("taskTitle").value,
    description: $("taskDescription").value,
    status: $("taskStatus").value,
    priority: $("taskPriority").value,
    dueDate: $("taskDueDate").value || null
  };
  try {
    const data = await api(id ? `/api/tasks/${id}` : "/api/tasks", {
      method: id ? "PUT" : "POST",
      body: JSON.stringify(body)
    });
    if (id) {
      const i = tasks.findIndex(t => t._id === id);
      if (i >= 0) tasks[i] = data;
    } else {
      tasks.unshift(data);
    }
    render();
    closeModal();
    showToast(id ? "Task updated" : "Task created");
  } catch (err) { showToast(err.message); }
});

document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  activeFilter = btn.dataset.filter;
  render();
}));

$("searchInput").addEventListener("input", render);

async function boot() {
  const savedUser = localStorage.getItem("taskflow_user");
  if (token && savedUser) {
    currentUser = JSON.parse(savedUser);
    try {
      const data = await api("/api/auth/me");
      currentUser = data.user;
      openApp();
    } catch { logout(); }
  }
}
boot();
