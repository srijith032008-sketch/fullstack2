const API_BASE = window.location.origin.includes('5500') || window.location.protocol === 'file:'
  ? 'http://localhost:5000/api'
  : '/api';

const FALLBACK_PROJECTS = [
  {
    title: 'SpatterSense',
    tagline: 'AI-assisted bloodstain pattern analysis',
    description: 'Applies machine learning to forensic bloodstain pattern analysis, estimating impact angle and point of origin from stain geometry to support crime scene reconstruction.',
    stack: 'Python, OpenCV, scikit-learn',
    category: 'AI / Forensics'
  },
  {
    title: 'Live Stock/Crypto Price Alert Engine',
    tagline: 'Real-time price alerting with custom data structures',
    description: 'A capstone engine that watches live stock and crypto prices and fires alerts when user-defined thresholds are crossed. Built around hash maps for O(1) symbol lookup, a priority queue/heap for the next-alert schedule, and circular buffers for rolling price history.',
    stack: 'Python, Hash Maps, Priority Queues, Circular Buffers',
    category: 'Systems / Data Structures'
  },
  {
    title: 'F1 Race Management System',
    tagline: 'A race season modeled in pure Java OOP',
    description: 'Models an F1 season end to end: drivers, teams, races, and standings. Built to demonstrate all four OOP pillars, with encapsulated driver/team state, inheritance across race event types, polymorphic scoring rules, and abstracted race operations.',
    stack: 'Java',
    category: 'Object-Oriented Systems'
  },
  {
    title: 'F1 Fan Hub',
    tagline: 'A race weekend, in one page',
    description: 'A front-end fan site for Formula 1 with a season race calendar, driver cards, circuit imagery, and a booking modal for grandstand tickets.',
    stack: 'HTML, CSS, JavaScript',
    category: 'Web Development'
  }
];

function renderProjects(projects) {
  const log = document.getElementById('project-log');
  const countEl = document.getElementById('project-count');
  if (!projects || projects.length === 0) {
    log.innerHTML = '<p class="log-empty">No entries yet — check back soon.</p>';
    return;
  }
  countEl.textContent = projects.length;
  log.innerHTML = projects.map((p, i) => `
    <article class="project-entry">
      <span class="entry-index">${String(i + 1).padStart(2, '0')}</span>
      <div class="entry-body">
        <h3>${escapeHTML(p.title)}</h3>
        <p class="entry-tagline">${escapeHTML(p.tagline)}</p>
        <p class="entry-desc">${escapeHTML(p.description)}</p>
        <div class="entry-meta">
          <span class="entry-category">${escapeHTML(p.category)}</span>
          <span class="entry-stack">${escapeHTML(p.stack)}</span>
        </div>
      </div>
    </article>
  `).join('');
}

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function loadProjects() {
  try {
    const res = await fetch(`${API_BASE}/projects`);
    if (!res.ok) throw new Error('bad response');
    const data = await res.json();
    renderProjects(data);
  } catch (err) {
    renderProjects(FALLBACK_PROJECTS);
  }
}

async function handleContactSubmit(event) {
  event.preventDefault();
  const form = event.target;
  const status = document.getElementById('form-status');
  const payload = {
    name: form.name.value.trim(),
    email: form.email.value.trim(),
    message: form.message.value.trim()
  };

  status.textContent = 'Sending…';

  try {
    const res = await fetch(`${API_BASE}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('send failed');
    status.textContent = 'Message sent. I\'ll get back to you soon.';
    form.reset();
  } catch (err) {
    status.textContent = 'Could not send right now — the backend may not be running.';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadProjects();
  document.getElementById('contact-form').addEventListener('submit', handleContactSubmit);
});
