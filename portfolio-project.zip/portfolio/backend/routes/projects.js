const express = require('express');
const router = express.Router();
const pool = require('../db');

router.get('/', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM projects ORDER BY display_order ASC');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch projects' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM projects WHERE id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Project not found' });
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch project' });
    }
});

router.post('/', async (req, res) => {
    const { title, tagline, description, stack, category, repo_url, live_url, display_order } = req.body;
    if (!title || !tagline || !description || !stack || !category) {
        return res.status(400).json({ error: 'title, tagline, description, stack, and category are required' });
    }
    try {
        const [result] = await pool.query(
            'INSERT INTO projects (title, tagline, description, stack, category, repo_url, live_url, display_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [title, tagline, description, stack, category, repo_url || '', live_url || '', display_order || 0]
        );
        res.status(201).json({ id: result.insertId });
    } catch (err) {
        res.status(500).json({ error: 'Failed to create project' });
    }
});

router.put('/:id', async (req, res) => {
    const { title, tagline, description, stack, category, repo_url, live_url, display_order } = req.body;
    try {
        const [result] = await pool.query(
            'UPDATE projects SET title=?, tagline=?, description=?, stack=?, category=?, repo_url=?, live_url=?, display_order=? WHERE id=?',
            [title, tagline, description, stack, category, repo_url || '', live_url || '', display_order || 0, req.params.id]
        );
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Project not found' });
        res.json({ updated: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to update project' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const [result] = await pool.query('DELETE FROM projects WHERE id = ?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Project not found' });
        res.json({ deleted: true });
    } catch (err) {
        res.status(500).json({ error: 'Failed to delete project' });
    }
});

module.exports = router;
