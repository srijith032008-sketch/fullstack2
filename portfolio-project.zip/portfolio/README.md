# Personal Portfolio Website

Full-stack portfolio: static frontend, an Express/Node API, and a MySQL database
that stores project entries and contact messages.

## Structure

```
portfolio/
  frontend/        HTML, CSS, JS — no build step
  backend/          Express API + MySQL connection
    routes/
  database/
    schema.sql      Table definitions + seed data
```

## 1. Database setup

Install MySQL locally (or use a hosted instance), then run:

```bash
mysql -u root -p < database/schema.sql
```

This creates the `portfolio` database, a `projects` table seeded with four
real projects, and a `messages` table for contact-form submissions.

## 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` with your MySQL credentials, then run:

```bash
npm start
```

The API serves on `http://localhost:5000` and also serves the frontend
directly from `/frontend`, so visiting `http://localhost:5000` in a browser
shows the full site.

API endpoints:

| Method | Route              | Purpose                     |
|--------|---------------------|------------------------------|
| GET    | /api/projects        | List all projects            |
| GET    | /api/projects/:id     | Get one project              |
| POST   | /api/projects         | Create a project             |
| PUT    | /api/projects/:id     | Update a project             |
| DELETE | /api/projects/:id     | Delete a project             |
| POST   | /api/messages         | Submit a contact message     |
| GET    | /api/messages         | List contact messages        |

## 3. Frontend-only preview

You can also open `frontend/index.html` directly, or serve it with
`Live Server` / `npx serve frontend`. Without the backend running, the page
falls back to a bundled copy of the same four projects so it never looks
broken — once the API is reachable it swaps in the live data automatically.

## 4. Deployment

The task brief lists Heroku, Netlify, or Vercel. A couple of practical notes:

- **Heroku** no longer has a free tier (discontinued Nov 2022), so if cost
  matters, **Render** or **Railway** are the closest free-tier equivalents
  for hosting the Node/Express backend + MySQL together.
- **Netlify** and **Vercel** are built for static/frontend hosting and
  serverless functions — great for `frontend/`, but they don't run a
  persistent MySQL-connected Express server the way this backend is written.

Recommended split, using only free tiers:

1. **Database** — a free MySQL instance on [Railway](https://railway.app) or
   [Aiven](https://aiven.io).
2. **Backend** — deploy `backend/` to **Render** (Web Service, Node
   environment). Set the same variables from `.env.example` in Render's
   dashboard, pointing `DB_HOST`/`DB_USER`/etc. at your hosted database.
3. **Frontend** — deploy `frontend/` to **Netlify** or **Vercel** as a static
   site. Update `API_BASE` in `script.js` to your Render backend's URL.

If you'd rather keep everything on one host, Render can also serve the
frontend directly (as `server.js` already does via `express.static`) — in
that case you only need step 1 and 2, and can skip Netlify/Vercel entirely.

## 5. What's already personalized

The seed data in `database/schema.sql` and the `FALLBACK_PROJECTS` array in
`script.js` are pre-filled with four of your real projects — SpatterSense,
the Live Stock/Crypto Price Alert Engine, the F1 Race Management System, and
the F1 Fan Hub. Add `repo_url` and `live_url` values once those projects have
public links, and add more rows to `projects` (or POST to `/api/projects`)
as you build more.
