CREATE DATABASE IF NOT EXISTS portfolio;
USE portfolio;

CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    tagline VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    stack VARCHAR(200) NOT NULL,
    category VARCHAR(60) NOT NULL,
    repo_url VARCHAR(300),
    live_url VARCHAR(300),
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO projects (title, tagline, description, stack, category, repo_url, live_url, display_order) VALUES
(
    'SpatterSense',
    'AI-assisted bloodstain pattern analysis',
    'Applies machine learning to forensic bloodstain pattern analysis, estimating impact angle and point of origin from stain geometry to support crime scene reconstruction.',
    'Python, OpenCV, scikit-learn',
    'AI / Forensics',
    '',
    '',
    1
),
(
    'Live Stock/Crypto Price Alert Engine',
    'Real-time price alerting with custom data structures',
    'A capstone engine that watches live stock and crypto prices and fires alerts when user-defined thresholds are crossed. Built around hash maps for O(1) symbol lookup, a priority queue/heap for the next-alert schedule, and circular buffers for rolling price history.',
    'Python, Hash Maps, Priority Queues, Circular Buffers',
    'Systems / Data Structures',
    '',
    '',
    2
),
(
    'F1 Race Management System',
    'A race season modeled in pure Java OOP',
    'Models an F1 season end to end: drivers, teams, races, and standings. Built to demonstrate all four OOP pillars, with encapsulated driver/team state, inheritance across race event types, polymorphic scoring rules, and abstracted race operations.',
    'Java',
    'Object-Oriented Systems',
    '',
    '',
    3
),
(
    'F1 Fan Hub',
    'A race weekend, in one page',
    'A front-end fan site for Formula 1 with a season race calendar, driver cards, circuit imagery, and a booking modal for grandstand tickets.',
    'HTML, CSS, JavaScript',
    'Web Development',
    '',
    '',
    4
);
