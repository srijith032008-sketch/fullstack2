# InkSpace — Blog Platform with Comments

Full-stack blogging platform built for the assignment.

## Requirements covered

- User registration, login and authentication
- JWT authorization
- Password hashing
- Create, edit and delete blog posts
- Comment section for user interaction
- RESTful APIs
- MongoDB database integration
- Responsive desktop/mobile interface
- User-specific post editing/deletion

## Tech stack

Frontend: HTML5, CSS3, JavaScript

Backend: Node.js + Express.js

Database: MongoDB + Mongoose

Authentication: JWT + bcryptjs

## Setup

1. Install Node.js 18+.
2. Extract this project and open it in VS Code.
3. Open the terminal in the project folder.
4. Install dependencies:

```bash
npm install
```

5. Copy `.env.example` to `.env`.

6. Add your MongoDB Atlas connection:

```env
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_long_random_secret
```

7. Start:

```bash
npm start
```

8. Open:

```text
http://localhost:5000
```

Development mode:

```bash
npm run dev
```

## API endpoints

Authentication:

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
```

Blog posts:

```text
GET    /api/posts
GET    /api/posts/:id
POST   /api/posts
PUT    /api/posts/:id
DELETE /api/posts/:id
```

Comments:

```text
POST   /api/posts/:id/comments
DELETE /api/comments/:id
```

Health:

```text
GET /api/health
```

Protected routes require:

```text
Authorization: Bearer YOUR_JWT_TOKEN
```

## Submission demo

For your assignment, demonstrate:

1. Register a new user.
2. Log in.
3. Create a blog post.
4. Edit the post.
5. Open the post and add a comment.
6. Delete your comment.
7. Delete your post.
8. Show the MongoDB collections.
9. Show the REST API working.
10. Show the mobile responsive layout.

## Deployment

Deploy the Node.js app to Render, Railway, or another Node-compatible service.

Build command:

```text
npm install
```

Start command:

```text
npm start
```

Set these environment variables on the host:

```text
MONGODB_URI
JWT_SECRET
PORT
```

The Express server serves the frontend from `public/`.

## Customize

Change the site name in `public/index.html`.

Replace the sample branding, colors and text with your own details if required.
