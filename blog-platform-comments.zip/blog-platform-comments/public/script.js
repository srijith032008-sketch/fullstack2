let token = localStorage.getItem("inkspace_token");
let user = JSON.parse(localStorage.getItem("inkspace_user") || "null");
let posts = [];

const $ = id => document.getElementById(id);

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2500);
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}

function esc(s = "") {
  return s.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

function setUser() {
  $("loginOpen").classList.toggle("hidden", !!user);
  $("registerOpen").classList.toggle("hidden", !!user);
  $("logoutBtn").classList.toggle("hidden", !user);
  $("newPostBtn").classList.toggle("hidden", !user);
  $("navUser").textContent = user ? `Hi, ${user.name}` : "";
}

$("loginOpen").onclick = () => openAuth("login");
$("registerOpen").onclick = () => openAuth("register");
$("heroWrite").onclick = () => user ? openPost() : openAuth("register");
$("newPostBtn").onclick = () => openPost();
$("logoutBtn").onclick = () => {
  token = null; user = null;
  localStorage.removeItem("inkspace_token");
  localStorage.removeItem("inkspace_user");
  setUser(); toast("Logged out");
};

function openAuth(mode) {
  $("authModal").classList.remove("hidden");
  document.querySelectorAll(".auth-tab").forEach(b => b.classList.toggle("active", b.dataset.auth === mode));
  $("loginForm").classList.toggle("hidden", mode !== "login");
  $("registerForm").classList.toggle("hidden", mode !== "register");
}

document.querySelectorAll(".auth-tab").forEach(b => b.onclick = () => openAuth(b.dataset.auth));
document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => $(b.dataset.close).classList.add("hidden"));

$("loginForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const data = await api("/api/auth/login", {
      method:"POST",
      body:JSON.stringify({email:$("loginEmail").value,password:$("loginPassword").value})
    });
    saveSession(data); $("authModal").classList.add("hidden"); toast("Welcome back!");
  } catch(err) { toast(err.message); }
};

$("registerForm").onsubmit = async e => {
  e.preventDefault();
  try {
    const data = await api("/api/auth/register", {
      method:"POST",
      body:JSON.stringify({name:$("regName").value,email:$("regEmail").value,password:$("regPassword").value})
    });
    saveSession(data); $("authModal").classList.add("hidden"); toast("Account created!");
  } catch(err) { toast(err.message); }
};

function saveSession(data) {
  token = data.token; user = data.user;
  localStorage.setItem("inkspace_token", token);
  localStorage.setItem("inkspace_user", JSON.stringify(user));
  setUser();
}

async function loadPosts() {
  try { posts = await api("/api/posts"); renderPosts(); }
  catch(err) { toast(err.message); }
}

function renderPosts() {
  $("postGrid").innerHTML = posts.length ? posts.map((p, i) => `
    <article class="post-card">
      <div class="post-cover">${esc(p.title.charAt(0).toUpperCase())}</div>
      <div class="post-body">
        <span class="category">${esc(p.category)}</span>
        <h3>${esc(p.title)}</h3>
        <p class="excerpt">${esc(p.content)}</p>
        <div class="post-meta">
          <span>By ${esc(p.author?.name || "User")} · ${new Date(p.createdAt).toLocaleDateString()}</span>
          <span>${p.commentCount || 0} 💬</span>
        </div>
        <div class="post-actions">
          <button class="btn primary mini" onclick="readPost('${p._id}')">Read post</button>
          ${user && p.author?._id === user.id ? `
            <button class="btn outline mini" onclick="editPost('${p._id}')">Edit</button>
            <button class="btn outline mini" onclick="deletePost('${p._id}')">Delete</button>
          ` : ""}
        </div>
      </div>
    </article>
  `).join("") : `<div class="empty"><h3>No posts yet</h3><p>Be the first person to publish a story.</p></div>`;
}

function openPost(post = null) {
  $("postModal").classList.remove("hidden");
  $("postId").value = post?._id || "";
  $("postTitle").value = post?.title || "";
  $("postCategory").value = post?.category || "";
  $("postContent").value = post?.content || "";
  $("postModalEyebrow").textContent = post ? "EDIT STORY" : "NEW STORY";
  $("postModalTitle").textContent = post ? "Edit your post" : "Write a post";
  $("postSave").textContent = post ? "Save changes" : "Publish post";
}

window.editPost = id => {
  const post = posts.find(p => p._id === id);
  if (post) openPost(post);
};

window.deletePost = async id => {
  if (!confirm("Delete this post and its comments?")) return;
  try {
    await api(`/api/posts/${id}`, { method:"DELETE" });
    toast("Post deleted"); loadPosts();
  } catch(err) { toast(err.message); }
};

$("postForm").onsubmit = async e => {
  e.preventDefault();
  const id = $("postId").value;
  const body = {
    title:$("postTitle").value,
    category:$("postCategory").value,
    content:$("postContent").value
  };
  try {
    await api(id ? `/api/posts/${id}` : "/api/posts", {
      method:id ? "PUT" : "POST",
      body:JSON.stringify(body)
    });
    $("postModal").classList.add("hidden");
    toast(id ? "Post updated" : "Post published");
    loadPosts();
  } catch(err) { toast(err.message); }
};

window.readPost = async id => {
  try {
    const data = await api(`/api/posts/${id}`);
    $("readerContent").innerHTML = `
      <article>
        <span class="category">${esc(data.post.category)}</span>
        <h1>${esc(data.post.title)}</h1>
        <div class="author">By ${esc(data.post.author?.name || "User")} · ${new Date(data.post.createdAt).toLocaleDateString()}</div>
        <div class="content">${esc(data.post.content)}</div>
        <div class="comments">
          <h3>Comments (${data.comments.length})</h3>
          ${data.comments.map(c => `
            <div class="comment">
              <strong>${esc(c.author?.name || "User")}</strong>
              <p>${esc(c.text)}</p>
              ${user && c.author?._id === user.id ? `<button class="btn outline mini" onclick="deleteComment('${c._id}','${id}')">Delete</button>` : ""}
            </div>
          `).join("") || `<p class="muted">No comments yet. Start the conversation.</p>`}
          ${user ? `
            <form class="comment-form" onsubmit="addComment(event,'${id}')">
              <input id="commentInput" placeholder="Write a comment..." required>
              <button class="btn primary">Comment</button>
            </form>` : `<p class="muted">Log in to join the conversation.</p>`}
        </div>
      </article>`;
    $("readerModal").classList.remove("hidden");
  } catch(err) { toast(err.message); }
};

window.addComment = async (event, id) => {
  event.preventDefault();
  const input = $("commentInput");
  try {
    await api(`/api/posts/${id}/comments`, { method:"POST", body:JSON.stringify({text:input.value}) });
    toast("Comment added"); readPost(id); loadPosts();
  } catch(err) { toast(err.message); }
};

window.deleteComment = async (commentId, postId) => {
  try {
    await api(`/api/comments/${commentId}`, {method:"DELETE"});
    toast("Comment deleted"); readPost(postId); loadPosts();
  } catch(err) { toast(err.message); }
};

async function boot() {
  setUser();
  if (token) {
    try {
      const data = await api("/api/auth/me");
      user = data.user;
      localStorage.setItem("inkspace_user", JSON.stringify(user));
      setUser();
    } catch {
      token = null; user = null;
      localStorage.removeItem("inkspace_token");
      localStorage.removeItem("inkspace_user");
      setUser();
    }
  }
  loadPosts();
}
boot();
