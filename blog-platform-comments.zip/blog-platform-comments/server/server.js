const express = require("express");
const path = require("path");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "development_secret_change_me";

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true }
}, { timestamps: true });

const postSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  content: { type: String, required: true },
  category: { type: String, default: "General", trim: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

const commentSchema = new mongoose.Schema({
  text: { type: String, required: true, trim: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  post: { type: mongoose.Schema.Types.ObjectId, ref: "Post", required: true }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Post = mongoose.model("Post", postSchema);
const Comment = mongoose.model("Comment", commentSchema);

function tokenFor(user) {
  return jwt.sign({ id: user._id.toString(), email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Login required" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired session" });
  }
}

app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "Blog API is running" });
});

/* Authentication */
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ message: "Name, email and password are required" });
    if (password.length < 6)
      return res.status(400).json({ message: "Password must be at least 6 characters" });

    if (await User.findOne({ email }))
      return res.status(409).json({ message: "Email is already registered" });

    const user = await User.create({
      name,
      email,
      password: await bcrypt.hash(password, 10)
    });

    res.status(201).json({
      token: tokenFor(user),
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch {
    res.status(500).json({ message: "Could not create account" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: "Incorrect email or password" });

    res.json({
      token: tokenFor(user),
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch {
    res.status(500).json({ message: "Could not log in" });
  }
});

app.get("/api/auth/me", auth, async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json({ user });
});

/* Posts */
app.get("/api/posts", async (req, res) => {
  try {
    const posts = await Post.find()
      .populate("author", "name")
      .sort({ createdAt: -1 });

    const counts = await Comment.aggregate([
      { $group: { _id: "$post", count: { $sum: 1 } } }
    ]);
    const countMap = Object.fromEntries(counts.map(x => [x._id.toString(), x.count]));

    res.json(posts.map(post => ({
      ...post.toObject(),
      commentCount: countMap[post._id.toString()] || 0
    })));
  } catch {
    res.status(500).json({ message: "Could not load posts" });
  }
});

app.get("/api/posts/:id", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate("author", "name");
    if (!post) return res.status(404).json({ message: "Post not found" });

    const comments = await Comment.find({ post: post._id })
      .populate("author", "name")
      .sort({ createdAt: -1 });

    res.json({ post, comments });
  } catch {
    res.status(400).json({ message: "Invalid post ID" });
  }
});

app.post("/api/posts", auth, async (req, res) => {
  try {
    const { title, content, category } = req.body;
    if (!title || !content)
      return res.status(400).json({ message: "Title and content are required" });

    const post = await Post.create({
      title,
      content,
      category: category || "General",
      author: req.user.id
    });

    const populated = await post.populate("author", "name");
    res.status(201).json(populated);
  } catch {
    res.status(500).json({ message: "Could not create post" });
  }
});

app.put("/api/posts/:id", auth, async (req, res) => {
  try {
    const post = await Post.findOneAndUpdate(
      { _id: req.params.id, author: req.user.id },
      { title: req.body.title, content: req.body.content, category: req.body.category },
      { new: true, runValidators: true }
    ).populate("author", "name");

    if (!post) return res.status(404).json({ message: "Post not found or not yours" });
    res.json(post);
  } catch {
    res.status(400).json({ message: "Could not update post" });
  }
});

app.delete("/api/posts/:id", auth, async (req, res) => {
  try {
    const post = await Post.findOneAndDelete({ _id: req.params.id, author: req.user.id });
    if (!post) return res.status(404).json({ message: "Post not found or not yours" });

    await Comment.deleteMany({ post: req.params.id });
    res.json({ success: true });
  } catch {
    res.status(400).json({ message: "Could not delete post" });
  }
});

/* Comments */
app.post("/api/posts/:id/comments", auth, async (req, res) => {
  try {
    if (!req.body.text || !req.body.text.trim())
      return res.status(400).json({ message: "Comment cannot be empty" });

    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const comment = await Comment.create({
      text: req.body.text,
      author: req.user.id,
      post: post._id
    });

    const populated = await comment.populate("author", "name");
    res.status(201).json(populated);
  } catch {
    res.status(500).json({ message: "Could not add comment" });
  }
});

app.delete("/api/comments/:id", auth, async (req, res) => {
  try {
    const comment = await Comment.findOneAndDelete({
      _id: req.params.id,
      author: req.user.id
    });
    if (!comment) return res.status(404).json({ message: "Comment not found or not yours" });
    res.json({ success: true });
  } catch {
    res.status(400).json({ message: "Could not delete comment" });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

async function start() {
  if (!process.env.MONGODB_URI) {
    console.error("MONGODB_URI is missing. Create .env from .env.example.");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB");
    app.listen(PORT, () => console.log(`Blog platform running at http://localhost:${PORT}`));
  } catch (err) {
    console.error("MongoDB connection error:", err.message);
    process.exit(1);
  }
}

start();
